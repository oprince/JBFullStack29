# JBFullStack29

# Ex 6: Draw lines

- Add “draw colored bars” button that will paint the following on the canvas
![image](https://user-images.githubusercontent.com/12232897/147269882-9d68221d-8a25-4c81-8fe6-a64716523348.png)

- Use a loop that will calculate the bar coordinates, direction (vertical or horizontal) and color. 
- The color options should be represented in an array.
- Represent the bar to be painted using an object.
- Pass the bar object to `drawBar()` function
- Add input field were number of bars should be entered by the user.


**Advanced:** Add “rotate colored bars” button that will draw a 45° rotated version of the above image
